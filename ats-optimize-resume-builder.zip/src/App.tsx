/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  FileText, 
  Download, 
  RefreshCw, 
  Send, 
  CheckCircle2, 
  Layout, 
  ChevronRight,
  Sparkles,
  FileJson,
  AlertCircle,
  FileUp,
  X,
  Eye,
  EyeOff,
  Info,
  MoreHorizontal,
  AlertTriangle
} from 'lucide-react';
import { ResumeData, TemplateId, CustomizationSettings } from './types';
import { optimizeResume, updateResumeWithFeedback } from './services/geminiService';
import { 
  MinimalTemplate, 
  ModernTemplate, 
  TechnicalTemplate, 
  ProfessionalTemplate, 
  CreativeTemplate, 
  ElegantTemplate, 
  CompactTemplate, 
  ExecutiveTemplate,
  BrutalistTemplate,
  EditorialTemplate,
  LuxuryTemplate,
  GeometricTemplate
} from './components/Templates';
import { cn } from './lib/utils';
// pdfjs-dist is imported dynamically in extractTextFromPDF to avoid interference
import { 
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Palette, Type as TypeIcon, MoveVertical } from 'lucide-react';

// Set up PDF.js worker is now handled inside extractTextFromPDF

function ErrorAlert({ message, onClear }: { message: string, onClear: () => void }) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: -10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      className="relative mb-6 p-5 bg-white border border-red-100 rounded-2xl shadow-xl shadow-red-50/50 flex flex-col gap-3 overflow-hidden group"
    >
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center text-red-600 shrink-0 rotate-3 group-hover:rotate-0 transition-transform">
          <AlertTriangle size={24} />
        </div>
        <div className="flex-1 pt-1">
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-base font-bold text-slate-900">System Alert</h4>
            <button onClick={onClear} className="p-1 hover:bg-slate-100 rounded-full transition-colors">
              <X size={16} className="text-slate-400" />
            </button>
          </div>
          <p className="text-sm text-slate-500 leading-relaxed">{message}</p>
        </div>
      </div>
      
      <div className="flex items-center gap-3 mt-2 pt-3 border-t border-slate-50">
        <button 
          onClick={() => setShowDetails(!showDetails)}
          className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors flex items-center gap-1"
        >
          <Info size={12} /> {showDetails ? 'Hide' : 'Show'} Debug Info
        </button>
        <div className="h-1 w-1 bg-slate-200 rounded-full" />
        <button 
          onClick={() => window.location.reload()}
          className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-indigo-600 transition-colors"
        >
          Refresh System
        </button>
      </div>

      {showDetails && (
        <motion.pre 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          className="mt-2 p-3 bg-slate-900 rounded-xl text-[10px] font-mono text-indigo-300 overflow-x-auto"
        >
          {JSON.stringify({ timestamp: new Date().toISOString(), error: message }, null, 2)}
        </motion.pre>
      )}
    </motion.div>
  );
}

function SortableItem({ id, label, isHidden, onToggleVisibility }: { id: string, label: string, isHidden: boolean, onToggleVisibility: (id: string) => void }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      className={cn(
        "flex items-center justify-between p-3 border rounded-lg mb-2 transition-all",
        isHidden ? "bg-slate-50 border-slate-100 opacity-50" : "bg-white border-slate-200 shadow-sm"
      )}
    >
      <div className="flex items-center gap-3">
        <button 
          onClick={() => onToggleVisibility(id)}
          className={cn(
            "p-1 rounded-md transition-colors",
            isHidden ? "text-slate-400 hover:text-slate-600" : "text-indigo-600 hover:bg-indigo-50"
          )}
        >
          {isHidden ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
        <span className={cn("text-sm font-medium", isHidden ? "text-slate-400 line-through" : "text-slate-700")}>
          {label}
        </span>
      </div>
      <button {...attributes} {...listeners} className="text-slate-300 hover:text-slate-500 cursor-grab active:cursor-grabbing transition-colors">
        <div className="grid grid-cols-2 gap-0.5">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="w-1 h-1 bg-current rounded-full" />
          ))}
        </div>
      </button>
    </div>
  );
}

export default function App() {
  const [step, setStep] = useState<'input' | 'processing' | 'preview'>('input');
  const [rawText, setRawText] = useState('');
  const [resumeData, setResumeData] = useState<ResumeData | null>(null);
  const [template, setTemplate] = useState<TemplateId>('minimal');
  const [settings, setSettings] = useState<CustomizationSettings>({
    fontFamily: 'sans',
    fontSize: 'base',
    spacing: 'normal',
    accentColor: '#4f46e5',
    sectionOrder: ['summary', 'experience', 'projects', 'education', 'skills', 'languages', 'interests'],
    hiddenSections: []
  });
  const [activeTab, setActiveTab] = useState<'template' | 'customize' | 'feedback'>('template');
  const [feedback, setFeedback] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [showDebug, setShowDebug] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  
  const previewRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (active.id !== over.id) {
      setSettings((prev) => ({
        ...prev,
        sectionOrder: arrayMove(
          prev.sectionOrder, 
          prev.sectionOrder.indexOf(active.id), 
          prev.sectionOrder.indexOf(over.id)
        ),
      }));
    }
  };

  const toggleSectionVisibility = (id: string) => {
    setSettings(prev => ({
      ...prev,
      hiddenSections: prev.hiddenSections.includes(id)
        ? prev.hiddenSections.filter(s => s !== id)
        : [...prev.hiddenSections, id]
    }));
  };

  const colorThemes = [
    { name: 'Indigo', color: '#4f46e5' },
    { name: 'Slate', color: '#0f172a' },
    { name: 'Emerald', color: '#10b981' },
    { name: 'Rose', color: '#f43f5e' },
    { name: 'Amber', color: '#f59e0b' },
    { name: 'Violet', color: '#8b5cf6' },
    { name: 'Sky', color: '#0ea5e9' },
    { name: 'Teal', color: '#14b8a6' },
  ];

  const extractTextFromPDF = async (file: File): Promise<string> => {
    try {
      // Dynamic import for PDF.js
      const pdfjsModule = await import('pdfjs-dist');
      // Handle different import styles (some environments might wrap it in .default)
      const pdfjs = (pdfjsModule as any).default || pdfjsModule;
      
      pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        'pdfjs-dist/build/pdf.worker.mjs',
        import.meta.url
      ).toString();

      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjs.getDocument({ 
        data: arrayBuffer,
        useSystemFonts: true, // Can help with some PDFs
      });
      
      loadingTask.onPassword = () => {
        throw new Error('This PDF is password protected. Please remove the password and try again.');
      };

      const pdf = await loadingTask.promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        // We can try to get text content with different options if needed
        const textContent = await page.getTextContent();
        
        const pageText = textContent.items
          .map((item: any) => {
            // Standard text item
            if (item.str !== undefined) return item.str;
            // Handle other potential structures in different PDF.js versions
            if (item.chars) return item.chars.map((c: any) => c.str).join('');
            return '';
          })
          .join(' ');
          
        fullText += pageText + '\n';
      }
      
      const result = fullText.trim();
      if (!result && pdf.numPages > 0) {
        console.warn('PDF has pages but no text was extracted. Likely a scanned document.');
      }
      
      return result;
    } catch (err: any) {
      console.error('PDF Extraction Error:', err);
      if (err.message?.includes('worker')) {
        throw new Error('PDF worker failed to initialize. This can happen if the browser blocks the worker script. Please try refreshing or using a different browser.');
      }
      if (err.name === 'PasswordException') {
        throw new Error('This PDF is password protected. Please upload an unprotected version.');
      }
      throw new Error(`Failed to read PDF: ${err.message || 'Unknown error'}`);
    }
  };

  const handleFile = async (file: File) => {
    setError(null);
    setFileName(file.name);
    try {
      let text = '';
      if (file.type === 'application/pdf') {
        text = await extractTextFromPDF(file);
      } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
        text = await file.text();
      } else if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
        text = await file.text();
      } else {
        throw new Error('Unsupported file type. Please upload a PDF, CSV, or TXT file.');
      }
      
      if (!text.trim()) {
        throw new Error('The file appears to be empty or contains no readable text. If it is a scanned PDF, please use an OCR tool first.');
      }
      
      setRawText(text);
    } catch (err: any) {
      console.error('File Upload Error:', err);
      let userMessage = err.message || 'An unexpected error occurred while reading the file.';
      if (userMessage.includes('failed to fetch')) {
        userMessage = 'Failed to load the file processing engine. Please check your internet connection and refresh the page.';
      }
      setError(userMessage);
      setFileName(null);
    }
  };

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, []);

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const handleProcess = async () => {
    if (!rawText.trim()) return;
    setStep('processing');
    setError(null);
    try {
      const data = await optimizeResume(rawText);
      setResumeData(data);
      setStep('preview');
    } catch (err: any) {
      console.error('Processing Error:', err);
      let message = 'Failed to process resume. Please try again.';
      if (err.message?.includes('fetch')) {
        message = 'Network error: Failed to connect to the AI service. Please check your connection and try again.';
      } else if (err.message?.includes('API_KEY')) {
        message = 'Configuration error: Gemini API key is missing or invalid.';
      }
      setError(message);
      setStep('input');
    }
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim() || !resumeData) return;
    setIsUpdating(true);
    setError(null);
    try {
      const updated = await updateResumeWithFeedback(resumeData, feedback);
      setResumeData(updated);
      setFeedback('');
    } catch (err: any) {
      console.error('Update Error:', err);
      let message = 'Failed to update resume. Please try again.';
      if (err.message?.includes('fetch')) {
        message = 'Network error: Failed to connect to the AI service. Please check your connection.';
      }
      setError(message);
    } finally {
      setIsUpdating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const downloadPDF = async () => {
    if (!previewRef.current || !resumeData) return;
    
    try {
      setIsDownloading(true);
      setError(null);

      const element = previewRef.current;
      const html = element.innerHTML;
      
      // Get all styles to ensure the PDF looks exactly like the preview
      const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
        .map(el => el.outerHTML)
        .join('\n');
      
      // Create a full HTML document for Puppeteer
      const fullHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            ${styles}
            <style>
              body { margin: 0; padding: 0; background: white; -webkit-print-color-adjust: exact; }
              /* Remove UI-only decorations for the PDF */
              .overflow-hidden { overflow: visible !important; }
              .rounded-xl { border-radius: 0 !important; }
              .shadow-2xl { box-shadow: none !important; }
            </style>
          </head>
          <body>
            <div class="${element.className}" style="box-shadow: none !important; border-radius: 0 !important; overflow: visible !important;">
              ${html}
            </div>
          </body>
        </html>
      `;

      const response = await fetch('/api/generate-pdf', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          html: fullHtml,
          fileName: `${resumeData.personalInfo.fullName.replace(/\s+/g, '_')}_Resume.pdf`
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate PDF on server');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resumeData.personalInfo.fullName.replace(/\s+/g, '_')}_Resume.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

    } catch (err: any) {
      console.error('PDF Generation Error:', err);
      setError(`Failed to generate PDF: ${err.message}. Please try the Print button as a fallback.`);
    } finally {
      setIsDownloading(false);
    }
  };

  const downloadCSV = () => {
    if (!resumeData) return;
    const rows = [
      ['Section', 'Key', 'Value'],
      ['Personal', 'Name', resumeData.personalInfo.fullName],
      ['Personal', 'Email', resumeData.personalInfo.email],
      ['Personal', 'Phone', resumeData.personalInfo.phone],
      ['Personal', 'Location', resumeData.personalInfo.location],
      ['Summary', 'Text', resumeData.summary],
      ...resumeData.experience.flatMap(exp => [
        ['Experience', 'Company', exp.company],
        ['Experience', 'Position', exp.position],
        ['Experience', 'Dates', `${exp.startDate} - ${exp.endDate}`],
        ...exp.highlights.map(h => ['Experience', 'Highlight', h])
      ]),
      ...resumeData.education.map(edu => ['Education', edu.degree, `${edu.school} (${edu.graduationDate})`]),
      ['Skills', 'List', resumeData.skills.join(', ')]
    ];
    
    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "resume_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
              <Sparkles size={18} />
            </div>
            <h1 className="font-bold text-lg tracking-tight">ATS-Optimize</h1>
          </div>
          
          {step === 'preview' && (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setStep('input')}
                className="text-sm font-medium text-slate-600 hover:text-slate-900 transition-colors px-3 py-1.5 rounded-md hover:bg-slate-100"
              >
                Start Over
              </button>
              <div className="h-4 w-[1px] bg-slate-200 mx-1" />
              <button 
                onClick={downloadCSV}
                className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-md hover:bg-slate-100"
              >
                <FileJson size={16} />
                CSV
              </button>
              <button 
                onClick={downloadPDF}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-1.5 rounded-md text-sm font-medium hover:bg-indigo-700 transition-all shadow-sm"
              >
                <Download size={16} />
                Download PDF
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {step === 'input' && (
            <motion.div 
              key="input"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-3xl mx-auto"
            >
              <div className="text-center mb-10">
                <h2 className="text-4xl font-bold tracking-tight text-slate-900 mb-4">
                  Build an ATS-Friendly Resume in Seconds
                </h2>
                <p className="text-slate-600 text-lg">
                  Upload your resume (PDF/CSV) or paste your content. Our AI will optimize it for Applicant Tracking Systems.
                </p>
              </div>

              <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-200 p-6">
                {/* File Upload Area */}
                <div 
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={cn(
                    "mb-6 border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all",
                    isDragging ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:border-indigo-400 hover:bg-slate-50"
                  )}
                >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={onFileChange} 
                    accept=".pdf,.csv,.txt" 
                    className="hidden" 
                  />
                  <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600">
                    <FileUp size={24} />
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-slate-900">
                      {fileName ? fileName : "Click to upload or drag and drop"}
                    </p>
                    <p className="text-sm text-slate-500 mt-1">
                      Support for PDF, CSV, and Text files
                    </p>
                  </div>
                  {fileName && (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setFileName(null);
                        setRawText('');
                      }}
                      className="mt-2 text-xs font-bold text-red-500 flex items-center gap-1 hover:underline"
                    >
                      <X size={14} /> Remove file
                    </button>
                  )}
                </div>

                <div className="relative mb-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-200"></div>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-slate-400 font-bold tracking-widest">Or paste content</span>
                  </div>
                </div>

                <div className="mb-6">
                  <textarea 
                    value={rawText}
                    onChange={(e) => setRawText(e.target.value)}
                    placeholder="Paste your current resume text here... Experience, education, skills, etc."
                    className="w-full h-48 p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none text-slate-600 leading-relaxed"
                  />
                </div>

                {error && <ErrorAlert message={error} onClear={() => setError(null)} />}

                <button 
                  onClick={handleProcess}
                  disabled={!rawText.trim()}
                  className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg"
                >
                  Optimize Resume
                  <ChevronRight size={20} />
                </button>

                <div className="mt-8 grid grid-cols-3 gap-4">
                  {[
                    { icon: CheckCircle2, label: 'ATS Optimized' },
                    { icon: Layout, label: 'Modern Templates' },
                    { icon: RefreshCw, label: 'AI Refinement' }
                  ].map((item, i) => (
                    <div key={i} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <item.icon size={20} className="text-indigo-600" />
                      <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {step === 'processing' && (
            <motion.div 
              key="processing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-20"
            >
              <div className="relative">
                <div className="w-20 h-20 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles size={24} className="text-indigo-600 animate-pulse" />
                </div>
              </div>
              <h3 className="mt-8 text-xl font-bold text-slate-900">Optimizing your content...</h3>
              <p className="mt-2 text-slate-500">Gemini is analyzing keywords and formatting for ATS compatibility.</p>
            </motion.div>
          )}

          {step === 'preview' && resumeData && (
            <motion.div 
              key="preview"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-8 items-start"
            >
              {/* Preview Area */}
              <div className="space-y-6">
                {error && <ErrorAlert message={error} onClear={() => setError(null)} />}
                
                <div className="flex flex-col gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-1 bg-slate-100 p-1 rounded-lg">
                      {(['template', 'customize', 'feedback'] as const).map((tab) => (
                        <button
                          key={tab}
                          onClick={() => setActiveTab(tab)}
                          className={cn(
                            "px-4 py-1.5 rounded-md text-xs font-bold transition-all uppercase tracking-wider",
                            activeTab === tab 
                              ? "bg-white text-slate-900 shadow-sm" 
                              : "text-slate-500 hover:text-slate-700"
                          )}
                        >
                          {tab}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-2 relative">
                      <div className="hidden sm:flex gap-2">
                        <button 
                          onClick={handlePrint}
                          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Print Resume"
                        >
                          <FileText size={20} />
                        </button>
                        <button 
                          onClick={downloadCSV}
                          className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Download CSV"
                        >
                          <FileJson size={20} />
                        </button>
                      </div>

                      <div className="relative">
                        <button 
                          onClick={() => setShowMoreMenu(!showMoreMenu)}
                          className={cn(
                            "p-2 rounded-lg transition-all",
                            showMoreMenu ? "bg-slate-900 text-white" : "text-slate-600 hover:bg-slate-100"
                          )}
                        >
                          <MoreHorizontal size={20} />
                        </button>

                        <AnimatePresence>
                          {showMoreMenu && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10, scale: 0.95 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: 10, scale: 0.95 }}
                              className="absolute right-0 mt-2 w-48 bg-white rounded-xl border border-slate-200 shadow-xl z-50 p-2"
                            >
                              <button 
                                onClick={() => { setShowDebug(!showDebug); setShowMoreMenu(false); }}
                                className="w-full flex items-center gap-3 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
                              >
                                <Info size={16} className="text-indigo-600" />
                                {showDebug ? 'Hide' : 'Show'} Raw Data
                              </button>
                              <button 
                                onClick={() => { handlePrint(); setShowMoreMenu(false); }}
                                className="w-full sm:hidden flex items-center gap-3 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
                              >
                                <FileText size={16} className="text-indigo-600" />
                                Print
                              </button>
                              <button 
                                onClick={() => { downloadCSV(); setShowMoreMenu(false); }}
                                className="w-full sm:hidden flex items-center gap-3 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
                              >
                                <FileJson size={16} className="text-indigo-600" />
                                CSV
                              </button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      <button 
                        onClick={downloadPDF}
                        disabled={isDownloading}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all shadow-md",
                          isDownloading 
                            ? "bg-slate-400 cursor-not-allowed text-white" 
                            : "bg-slate-900 text-white hover:bg-slate-800"
                        )}
                      >
                        {isDownloading ? (
                          <>
                            <RefreshCw size={18} className="animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Download size={18} />
                            Download PDF
                          </>
                        )}
                      </button>
                    </div>
                  </div>

                  {activeTab === 'template' && (
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                      {(['minimal', 'modern', 'technical', 'professional', 'creative', 'elegant', 'compact', 'executive', 'brutalist', 'editorial', 'luxury', 'geometric'] as TemplateId[]).map((t) => (
                        <button
                          key={t}
                          onClick={() => setTemplate(t)}
                          className={cn(
                            "px-2 py-2 rounded-lg text-[10px] font-bold transition-all border uppercase tracking-tighter",
                            template === t 
                              ? "bg-slate-900 text-white border-slate-900 shadow-md" 
                              : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                          )}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  )}

                  {activeTab === 'customize' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in slide-in-from-top-2">
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                          <TypeIcon size={12} /> Typography
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {(['sans', 'serif', 'mono', 'display'] as const).map((f) => (
                            <button
                              key={f}
                              onClick={() => setSettings(s => ({ ...s, fontFamily: f }))}
                              className={cn(
                                "px-3 py-2 rounded-lg text-xs font-medium border transition-all capitalize",
                                settings.fontFamily === f ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200 hover:border-slate-300"
                              )}
                            >
                              {f}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                          <MoveVertical size={12} /> Spacing & Size
                        </label>
                        <div className="flex flex-col gap-2">
                          <div className="flex gap-2">
                            {(['sm', 'base', 'lg'] as const).map((sz) => (
                              <button
                                key={sz}
                                onClick={() => setSettings(s => ({ ...s, fontSize: sz }))}
                                className={cn(
                                  "flex-1 px-2 py-1.5 rounded-lg text-[10px] font-bold border transition-all uppercase",
                                  settings.fontSize === sz ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200 hover:border-slate-300"
                                )}
                              >
                                {sz}
                              </button>
                            ))}
                          </div>
                          <div className="flex gap-2">
                            {(['compact', 'normal', 'relaxed'] as const).map((sp) => (
                              <button
                                key={sp}
                                onClick={() => setSettings(s => ({ ...s, spacing: sp }))}
                                className={cn(
                                  "flex-1 px-2 py-1.5 rounded-lg text-[10px] font-bold border transition-all uppercase",
                                  settings.spacing === sp ? "border-indigo-600 bg-indigo-50 text-indigo-700" : "border-slate-200 hover:border-slate-300"
                                )}
                              >
                                {sp}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                          <Palette size={12} /> Accent Color
                        </label>
                        <div className="grid grid-cols-4 gap-2">
                          {colorThemes.map((theme) => (
                            <button
                              key={theme.color}
                              onClick={() => setSettings(s => ({ ...s, accentColor: theme.color }))}
                              className={cn(
                                "w-full aspect-square rounded-lg border-2 transition-all flex items-center justify-center",
                                settings.accentColor === theme.color ? "border-slate-900 scale-105 shadow-sm" : "border-transparent hover:scale-105"
                              )}
                              style={{ backgroundColor: theme.color }}
                              title={theme.name}
                            >
                              {settings.accentColor === theme.color && <CheckCircle2 size={14} className="text-white" />}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                          <Layout size={12} /> Custom Color
                        </label>
                        <div className="flex items-center gap-2">
                          <input 
                            type="color" 
                            value={settings.accentColor}
                            onChange={(e) => setSettings(s => ({ ...s, accentColor: e.target.value }))}
                            className="w-10 h-10 rounded-lg border border-slate-200 p-1 bg-white cursor-pointer"
                          />
                          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">{settings.accentColor}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {showDebug && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-slate-900 rounded-xl p-6 text-indigo-300 font-mono text-[10px] overflow-x-auto shadow-inner"
                  >
                    <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
                      <span className="uppercase tracking-widest font-black text-slate-500">Raw Resume Data (Debug)</span>
                      <button onClick={() => setShowDebug(false)} className="text-slate-500 hover:text-white">
                        <X size={14} />
                      </button>
                    </div>
                    {JSON.stringify(resumeData, null, 2)}
                  </motion.div>
                )}

                <div 
                  ref={previewRef}
                  data-preview-container
                  className="overflow-hidden rounded-xl shadow-2xl shadow-slate-200/50"
                >
                  {template === 'minimal' && <MinimalTemplate data={resumeData} settings={settings} />}
                  {template === 'modern' && <ModernTemplate data={resumeData} settings={settings} />}
                  {template === 'technical' && <TechnicalTemplate data={resumeData} settings={settings} />}
                  {template === 'professional' && <ProfessionalTemplate data={resumeData} settings={settings} />}
                  {template === 'creative' && <CreativeTemplate data={resumeData} settings={settings} />}
                  {template === 'elegant' && <ElegantTemplate data={resumeData} settings={settings} />}
                  {template === 'compact' && <CompactTemplate data={resumeData} settings={settings} />}
                  {template === 'executive' && <ExecutiveTemplate data={resumeData} settings={settings} />}
                  {template === 'brutalist' && <BrutalistTemplate data={resumeData} settings={settings} />}
                  {template === 'editorial' && <EditorialTemplate data={resumeData} settings={settings} />}
                  {template === 'luxury' && <LuxuryTemplate data={resumeData} settings={settings} />}
                  {template === 'geometric' && <GeometricTemplate data={resumeData} settings={settings} />}
                </div>
              </div>

              {/* Sidebar Controls */}
              <div className="space-y-6 sticky top-24">
                {activeTab === 'customize' && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm animate-in slide-in-from-right-4">
                    <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <MoveVertical size={18} className="text-indigo-600" />
                      Section Order
                    </h3>
                    <p className="text-xs text-slate-500 mb-4">Drag to reorder or toggle visibility of sections</p>
                    <DndContext 
                      sensors={sensors}
                      collisionDetection={closestCenter}
                      onDragEnd={handleDragEnd}
                    >
                      <SortableContext 
                        items={settings.sectionOrder}
                        strategy={verticalListSortingStrategy}
                      >
                        {settings.sectionOrder.map(id => (
                          <SortableItem 
                            key={id} 
                            id={id} 
                            label={id.charAt(0).toUpperCase() + id.slice(1)} 
                            isHidden={settings.hiddenSections.includes(id)}
                            onToggleVisibility={toggleSectionVisibility}
                          />
                        ))}
                      </SortableContext>
                    </DndContext>
                  </div>
                )}

                {(activeTab === 'template' || activeTab === 'feedback') && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                      <RefreshCw size={18} className="text-indigo-600" />
                      AI Refinement
                    </h3>
                    <p className="text-sm text-slate-500 mb-4">
                      Need to tweak something? Just tell the AI what you want to change.
                    </p>
                    <form onSubmit={handleUpdate} className="space-y-4">
                      <textarea 
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        placeholder="e.g., 'Make my summary more punchy' or 'Add a new skill: React Native'"
                        className="w-full h-32 p-3 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none"
                      />
                      <button 
                        type="submit"
                        disabled={isUpdating || !feedback.trim()}
                        className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-md"
                      >
                        {isUpdating ? (
                          <RefreshCw size={18} className="animate-spin" />
                        ) : (
                          <>
                            <Send size={18} />
                            Update Resume
                          </>
                        )}
                      </button>
                    </form>
                  </div>
                )}

                <div className="bg-indigo-900 rounded-2xl p-6 text-white shadow-lg">
                  <h4 className="font-bold mb-2 flex items-center gap-2">
                    <CheckCircle2 size={18} className="text-emerald-400" />
                    ATS Ready
                  </h4>
                  <p className="text-indigo-200 text-xs leading-relaxed">
                    Your resume has been optimized with standard headers, clear sections, and keyword-rich bullet points that are easily parsed by modern HR software.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-slate-200 py-10 bg-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-slate-400 text-sm">
            © {new Date().getFullYear()} ATS-Optimize Resume Builder. Powered by Gemini AI.
          </p>
        </div>
      </footer>
    </div>
  );
}
