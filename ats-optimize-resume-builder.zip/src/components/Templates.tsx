import React from 'react';
import { ResumeData, CustomizationSettings, SkillGroup } from '../types';
import { cn } from '../lib/utils';

interface TemplateProps {
  data: ResumeData;
  settings: CustomizationSettings;
}

const getFontClass = (font: CustomizationSettings['fontFamily']) => {
  switch (font) {
    case 'serif': return 'font-serif';
    case 'mono': return 'font-mono';
    case 'display': return 'font-display';
    default: return 'font-sans';
  }
};

const getFontSizeClass = (size: CustomizationSettings['fontSize']) => {
  switch (size) {
    case 'sm': return 'text-xs';
    case 'lg': return 'text-base';
    default: return 'text-sm';
  }
};

const SectionHeader = ({ title, accentColor, variant = 'default' }: { title: string, accentColor: string, variant?: 'default' | 'sidebar' | 'technical' | 'elegant' }) => {
  if (variant === 'sidebar') {
    return <h2 className="text-xs font-black uppercase tracking-[0.2em] mb-4" style={{ color: accentColor }}>{title}</h2>;
  }
  if (variant === 'technical') {
    return (
      <div className="flex items-center gap-4 mb-4">
        <h2 className="text-xs font-bold uppercase tracking-widest whitespace-nowrap" style={{ color: accentColor }}>{title}</h2>
        <div className="h-[1px] w-full bg-slate-100"></div>
      </div>
    );
  }
  if (variant === 'elegant') {
    return (
      <div className="text-center mb-8">
        <h2 className="text-xs font-bold uppercase tracking-[0.3em] text-slate-400">{title}</h2>
        <div className="mt-2 w-12 h-[1px] bg-slate-200 mx-auto"></div>
      </div>
    );
  }
  return (
    <div className="mb-4">
      <h2 className="text-sm font-bold uppercase tracking-widest mb-1" style={{ color: accentColor }}>{title}</h2>
      <div className="h-1 w-12 rounded-full" style={{ backgroundColor: accentColor }}></div>
    </div>
  );
};

const SimpleListSection = ({ items, accentColor, variant = 'default' }: { items?: string[], accentColor: string, variant?: 'default' | 'sidebar' }) => {
  if (!items || items.length === 0) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item, i) => (
        <span key={i} className={cn(
          "text-[10px] font-bold px-2 py-0.5 rounded transition-all",
          variant === 'sidebar' 
            ? "bg-white/10 text-white border border-white/20 hover:bg-white/20" 
            : "bg-slate-50 text-slate-600 border border-slate-100 hover:border-indigo-200"
        )}>
          {item}
        </span>
      ))}
    </div>
  );
};

const Section: React.FC<{ id: string, settings: CustomizationSettings, children: React.ReactNode }> = ({ id, settings, children }) => {
  if (settings.hiddenSections.includes(id)) return null;
  return <>{children}</>;
};

export const MinimalTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  const renderSection = (id: string) => {
    return (
      <Section key={id} id={id} settings={settings}>
        {(() => {
          switch (id) {
            case 'summary':
              return (
                <section className="mb-8">
                  <SectionHeader title="Profile" accentColor={settings.accentColor} />
                  <p className={cn(fontSizeClass, "leading-relaxed text-slate-700")}>{data.summary}</p>
                </section>
              );
            case 'experience':
              return (
                <section className="mb-8">
                  <SectionHeader title="Experience" accentColor={settings.accentColor} />
                  <div className={cn("space-y-6", settings.spacing === 'compact' ? 'space-y-3' : settings.spacing === 'relaxed' ? 'space-y-8' : 'space-y-6')}>
                    {data.experience.map((exp, i) => (
                      <div key={i} className="group">
                        <div className="flex justify-between items-baseline mb-1">
                          <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{exp.position}</h3>
                          <span className="text-xs text-slate-500 font-medium bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">{exp.startDate} — {exp.endDate}</span>
                        </div>
                        <div className="flex justify-between items-baseline mb-2">
                          <span className="text-sm font-semibold text-slate-600">{exp.company}</span>
                          <span className="text-xs text-slate-400 italic">{exp.location}</span>
                        </div>
                        <ul className={cn("list-disc list-outside ml-4 text-slate-600 space-y-1.5", fontSizeClass)}>
                          {exp.highlights.map((h, j) => <li key={j}>{h}</li>)}
                        </ul>
                      </div>
                    ))}
                  </div>
                </section>
              );
            case 'projects':
              return data.projects && data.projects.length > 0 && (
                <section className="mb-8">
                  <SectionHeader title="Projects" accentColor={settings.accentColor} />
                  <div className="grid grid-cols-1 gap-4">
                    {data.projects.map((proj, i) => (
                      <div key={i} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:shadow-md transition-all">
                        <div className="flex justify-between items-center mb-2">
                          <h3 className="font-bold text-slate-900">{proj.name}</h3>
                          {proj.link && (
                            <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded bg-white border border-slate-200 hover:border-indigo-500 hover:text-indigo-600 transition-all">
                              View Project ↗
                            </a>
                          )}
                        </div>
                        <p className={cn("text-slate-600 mb-3", fontSizeClass)}>{proj.description}</p>
                        {proj.skills && (
                          <div className="flex flex-wrap gap-1">
                            {proj.skills.map((s, j) => <span key={j} className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">#{s}</span>)}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </section>
              );
            case 'education':
              return (
                <section className="mb-8">
                  <SectionHeader title="Education" accentColor={settings.accentColor} />
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {data.education.map((edu, i) => (
                      <div key={i} className="border-l-2 pl-4" style={{ borderColor: settings.accentColor }}>
                        <h3 className="text-sm font-bold text-slate-900">{edu.degree}</h3>
                        <p className="text-sm text-slate-600">{edu.school}</p>
                        <p className="text-xs text-slate-400 mt-1">{edu.graduationDate}</p>
                      </div>
                    ))}
                  </div>
                </section>
              );
            case 'skills':
              return (
                <section className="mb-8">
                  <SectionHeader title="Expertise" accentColor={settings.accentColor} />
                  <SkillSection skills={data.skills} accentColor={settings.accentColor} />
                </section>
              );
            case 'languages':
              return data.languages && data.languages.length > 0 && (
                <section className="mb-8">
                  <SectionHeader title="Languages" accentColor={settings.accentColor} />
                  <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
                </section>
              );
            case 'interests':
              return data.interests && data.interests.length > 0 && (
                <section className="mb-8">
                  <SectionHeader title="Interests" accentColor={settings.accentColor} />
                  <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
                </section>
              );
            default: return null;
          }
        })()}
      </Section>
    );
  };

  return (
    <div className={cn("p-12 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl min-h-[1100px]", fontClass)}>
      <header className="mb-12">
        <h1 className="text-5xl font-black tracking-tighter text-slate-900 mb-4">{data.personalInfo.fullName}</h1>
        <div className="flex flex-wrap gap-y-2 gap-x-6 text-xs font-bold uppercase tracking-widest text-slate-400">
          <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.email}</span>
          <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.phone}</span>
          <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.location}</span>
        </div>
      </header>
      {settings.sectionOrder
        .filter(id => !settings.hiddenSections.includes(id))
        .map(id => renderSection(id))}
    </div>
  );
};

export const ModernTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-0 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl flex min-h-[1100px]", fontClass)}>
      <aside className="w-1/3 text-white p-10 flex flex-col" style={{ backgroundColor: settings.accentColor }}>
        <div className="mb-12">
          <div className="w-20 h-20 rounded-2xl bg-white/20 flex items-center justify-center text-3xl font-black mb-6 border border-white/30 shadow-inner">
            {data.personalInfo.fullName.charAt(0)}
          </div>
          <h1 className="text-2xl font-black leading-tight mb-2 tracking-tighter">{data.personalInfo.fullName}</h1>
          <p className="text-white/60 text-xs font-bold uppercase tracking-widest">{data.experience[0]?.position}</p>
        </div>

        <div className="flex-1 space-y-10">
          <section>
            <SectionHeader title="Contact" accentColor="#fff" variant="sidebar" />
            <div className="space-y-3 text-xs text-white/70 font-medium">
              <p className="flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-white/50"></span>
                {data.personalInfo.email}
              </p>
              <p className="flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-white/50"></span>
                {data.personalInfo.phone}
              </p>
              <p className="flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-white/50"></span>
                {data.personalInfo.location}
              </p>
            </div>
          </section>

          <section>
            <SectionHeader title="Expertise" accentColor="#fff" variant="sidebar" />
            <SkillSection skills={data.skills} accentColor={settings.accentColor} variant="sidebar" />
          </section>

          {/* Sidebar content ends here */}
        </div>
      </aside>

      <main className="w-2/3 p-12 bg-slate-50/30">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-6 flex items-center gap-4">
                Profile
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <p className={cn("text-slate-600 leading-relaxed font-medium", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-8 flex items-center gap-4">
                Experience
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <div className="space-y-10 relative before:absolute before:left-0 before:top-2 before:bottom-0 before:w-[2px] before:bg-slate-100 pl-8">
                {data.experience.map((exp, i) => (
                  <div key={i} className="relative group">
                    <div className="absolute -left-[35px] top-1.5 w-4 h-4 rounded-full border-4 border-white shadow-sm group-hover:scale-110 transition-transform" style={{ backgroundColor: settings.accentColor }}></div>
                    <div className="mb-2">
                      <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors">{exp.position}</h3>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">{exp.company}</span>
                        <span className="text-[10px] font-black text-slate-400 bg-slate-100 px-2 py-0.5 rounded uppercase">{exp.startDate} — {exp.endDate}</span>
                      </div>
                    </div>
                    <ul className={cn("list-none text-slate-600 space-y-2 mt-4", fontSizeClass)}>
                      {exp.highlights.map((h, j) => (
                        <li key={j} className="flex gap-3">
                          <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: settings.accentColor }}></span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'projects' && data.projects && data.projects.length > 0) return (
            <section key="projects" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-8 flex items-center gap-4">
                Projects
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <div className="grid grid-cols-1 gap-6">
                {data.projects.map((proj, i) => (
                  <div key={i} className="group p-6 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-all">
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-black text-slate-900">{proj.name}</h3>
                      {proj.link && (
                        <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:underline">
                          Launch ↗
                        </a>
                      )}
                    </div>
                    <p className={cn("text-slate-600 leading-relaxed mb-4", fontSizeClass)}>{proj.description}</p>
                    {proj.skills && (
                      <div className="flex flex-wrap gap-1.5">
                        {proj.skills.map((s, j) => (
                          <span key={j} className="text-[9px] font-bold bg-slate-50 text-slate-400 px-2 py-0.5 rounded border border-slate-100">
                            {s}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'languages' && data.languages && data.languages.length > 0) return (
            <section key="languages" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-8 flex items-center gap-4">
                Languages
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'interests' && data.interests && data.interests.length > 0) return (
            <section key="interests" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-8 flex items-center gap-4">
                Interests
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'education' && data.education.length > 0) return (
            <section key="education" className="mb-12">
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-8 flex items-center gap-4">
                Education
                <div className="h-[1px] flex-1 bg-slate-200"></div>
              </h2>
              <div className="space-y-6">
                {data.education.map((edu, i) => (
                  <div key={i} className="group">
                    <div className="flex justify-between items-baseline mb-2">
                      <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors uppercase tracking-tight">{edu.degree}</h3>
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{edu.graduationDate}</span>
                    </div>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">{edu.school}</p>
                  </div>
                ))}
              </div>
            </section>
          );
          return null;
        })}
      </main>
    </div>
  );
};

export const TechnicalTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-12 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl min-h-[1100px] border-t-[12px]", fontClass)} style={{ borderTopColor: settings.accentColor }}>
      <header className="mb-12 flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-black tracking-tight mb-2 uppercase">{data.personalInfo.fullName}</h1>
          <p className="text-sm font-bold text-slate-400 tracking-[0.2em] uppercase">{data.experience[0]?.position}</p>
        </div>
        <div className="text-right space-y-1">
          <p className="text-xs font-bold text-slate-600">{data.personalInfo.email}</p>
          <p className="text-xs font-bold text-slate-600">{data.personalInfo.phone}</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{data.personalInfo.location}</p>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-12">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary">
              <SectionHeader title="System Overview" accentColor={settings.accentColor} variant="technical" />
              <p className={cn("text-slate-600 leading-relaxed font-mono bg-slate-50 p-4 rounded-lg border border-slate-100", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <SectionHeader title="Deployment History" accentColor={settings.accentColor} variant="technical" />
              <div className="space-y-8">
                {data.experience.map((exp, i) => (
                  <div key={i} className="relative pl-6 before:absolute before:left-0 before:top-1.5 before:bottom-0 before:w-[2px] before:bg-slate-100">
                    <div className="absolute left-[-4px] top-1.5 w-2 h-2 rounded-full" style={{ backgroundColor: settings.accentColor }}></div>
                    <div className="flex justify-between items-baseline mb-2">
                      <h3 className="text-base font-black uppercase tracking-tight">{exp.position} <span className="text-slate-400 font-normal">@</span> {exp.company}</h3>
                      <span className="text-[10px] font-black text-slate-400 bg-slate-50 px-2 py-1 rounded border border-slate-100">{exp.startDate} - {exp.endDate}</span>
                    </div>
                    <ul className={cn("list-none text-slate-600 space-y-2", fontSizeClass)}>
                      {exp.highlights.map((h, j) => (
                        <li key={j} className="flex gap-2">
                          <span className="text-slate-300 font-mono">$</span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'projects' && data.projects && data.projects.length > 0) return (
            <section key="projects">
              <SectionHeader title="Core Projects" accentColor={settings.accentColor} variant="technical" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {data.projects.map((proj, i) => (
                  <div key={i} className="p-5 rounded-xl border-2 border-slate-50 bg-white hover:border-indigo-100 transition-all group">
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-black text-sm uppercase tracking-tight">{proj.name}</h3>
                      {proj.link && (
                        <a 
                          href={proj.link} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-[10px] font-black text-white px-2 py-1 rounded transition-all transform group-hover:translate-x-1"
                          style={{ backgroundColor: settings.accentColor }}
                        >
                          SRC ↗
                        </a>
                      )}
                    </div>
                    <p className={cn("text-slate-500 mb-4 leading-relaxed", fontSizeClass)}>{proj.description}</p>
                    {proj.skills && (
                      <div className="flex flex-wrap gap-1.5">
                        {proj.skills.map((s, j) => (
                          <span key={j} className="text-[9px] font-mono font-bold text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded">
                            {s}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <SectionHeader title="Technical Stack" accentColor={settings.accentColor} variant="technical" />
              <SkillSection skills={data.skills} accentColor={settings.accentColor} variant="technical" />
            </section>
          );
          if (id === 'languages' && data.languages && data.languages.length > 0) return (
            <section key="languages">
              <SectionHeader title="Languages" accentColor={settings.accentColor} variant="technical" />
              <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'interests' && data.interests && data.interests.length > 0) return (
            <section key="interests">
              <SectionHeader title="Interests" accentColor={settings.accentColor} variant="technical" />
              <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

const SkillSection = ({ skills, accentColor, variant = 'default' }: { skills: ResumeData['skills'], accentColor: string, variant?: 'default' | 'sidebar' | 'technical' | 'pill' }) => {
  const isCategorized = Array.isArray(skills) && skills.length > 0 && typeof skills[0] === 'object' && 'category' in skills[0];

  if (isCategorized) {
    const groups = skills as SkillGroup[];
    return (
      <div className="space-y-4">
        {groups.map((group, i) => (
          <div key={i}>
            <h4 className={cn("text-[10px] font-black uppercase tracking-widest mb-2 opacity-50", variant === 'sidebar' ? 'text-white' : 'text-slate-500')}>
              {group.category}
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {group.items.map((item, j) => (
                <span key={j} className={cn(
                  "text-[10px] font-bold px-2 py-0.5 rounded transition-all",
                  variant === 'sidebar' 
                    ? "bg-white/10 text-white border border-white/20 hover:bg-white/20" 
                    : "bg-slate-50 text-slate-600 border border-slate-100 hover:border-indigo-200"
                )}>
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  const items = skills as string[];
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((skill, i) => (
        <span key={i} className={cn(
          "text-[10px] font-bold px-2.5 py-1 rounded-full transition-all shadow-sm",
          variant === 'sidebar'
            ? "bg-white/10 text-white border border-white/20 hover:bg-white/20"
            : "bg-white text-slate-700 border border-slate-200 hover:border-indigo-400"
        )}>
          {skill}
        </span>
      ))}
    </div>
  );
};

export const ProfessionalTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-16 bg-white text-slate-800 max-w-[800px] mx-auto shadow-2xl min-h-[1100px] border border-slate-100", fontClass)}>
      <div className="text-center mb-12">
        <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase">{data.personalInfo.fullName}</h1>
        <div className="flex justify-center flex-wrap gap-x-6 text-xs font-bold uppercase tracking-widest text-slate-400">
          <span className="flex items-center gap-2"><span className="w-1 h-1 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.email}</span>
          <span className="flex items-center gap-2"><span className="w-1 h-1 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.phone}</span>
          <span className="flex items-center gap-2"><span className="w-1 h-1 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.location}</span>
        </div>
      </div>

      <div className="space-y-12">
        {settings.sectionOrder.map(id => {
          if (id === 'summary') return (
            <section key="summary">
              <SectionHeader title="Executive Profile" accentColor={settings.accentColor} />
              <p className={cn("leading-relaxed text-slate-600 text-justify", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <SectionHeader title="Professional Experience" accentColor={settings.accentColor} />
              <div className="space-y-10">
                {data.experience.map((exp, i) => (
                  <div key={i} className="relative">
                    <div className="flex justify-between items-baseline mb-2">
                      <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight">{exp.position}</h3>
                      <span className="text-xs font-black text-slate-400 bg-slate-50 px-2 py-1 rounded border border-slate-100">{exp.startDate} — {exp.endDate}</span>
                    </div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm font-bold text-slate-500 uppercase tracking-widest">{exp.company}</span>
                      <span className="text-[10px] font-bold text-slate-400 italic">{exp.location}</span>
                    </div>
                    <ul className={cn("list-none text-slate-600 space-y-2.5", fontSizeClass)}>
                      {exp.highlights.map((h, j) => (
                        <li key={j} className="flex gap-4">
                          <span className="mt-2 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: settings.accentColor }}></span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'projects' && data.projects && data.projects.length > 0) return (
            <section key="projects">
              <SectionHeader title="Key Projects" accentColor={settings.accentColor} />
              <div className="grid grid-cols-1 gap-6">
                {data.projects.map((proj, i) => (
                  <div key={i} className="p-6 rounded-2xl border border-slate-100 bg-slate-50/30 hover:bg-white hover:shadow-lg transition-all">
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="font-black text-slate-900 uppercase tracking-tight">{proj.name}</h3>
                      {proj.link && (
                        <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-black text-indigo-600 hover:underline tracking-widest uppercase">
                          Case Study ↗
                        </a>
                      )}
                    </div>
                    <p className={cn("text-slate-600 leading-relaxed mb-4", fontSizeClass)}>{proj.description}</p>
                    {proj.skills && (
                      <div className="flex flex-wrap gap-2">
                        {proj.skills.map((s, j) => <span key={j} className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter border border-slate-200 px-1.5 py-0.5 rounded">#{s}</span>)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <SectionHeader title="Core Competencies" accentColor={settings.accentColor} />
              <SkillSection skills={data.skills} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'languages' && data.languages && data.languages.length > 0) return (
            <section key="languages">
              <SectionHeader title="Languages" accentColor={settings.accentColor} />
              <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'interests' && data.interests && data.interests.length > 0) return (
            <section key="interests">
              <SectionHeader title="Interests" accentColor={settings.accentColor} />
              <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

export const CreativeTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-0 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl overflow-hidden flex flex-col min-h-[1100px]", fontClass)}>
      <header className="text-white p-16 flex justify-between items-end relative overflow-hidden" style={{ backgroundColor: settings.accentColor }}>
        <div className="absolute top-[-20%] right-[-10%] w-64 h-64 rounded-full bg-white/10 blur-3xl"></div>
        <div className="absolute bottom-[-10%] left-[-5%] w-48 h-48 rounded-full bg-black/10 blur-2xl"></div>
        
        <div className="relative z-10">
          <h1 className="text-6xl font-black tracking-tighter uppercase leading-[0.85]">{data.personalInfo.fullName.split(' ')[0]}<br/><span className="text-white/50">{data.personalInfo.fullName.split(' ').slice(1).join(' ')}</span></h1>
          <p className="mt-6 text-white font-bold tracking-[0.3em] uppercase text-xs bg-black/20 inline-block px-3 py-1 rounded">{data.experience[0]?.position}</p>
        </div>
        <div className="text-right text-[10px] space-y-1 text-white/80 font-bold uppercase tracking-widest relative z-10">
          <p>{data.personalInfo.email}</p>
          <p>{data.personalInfo.phone}</p>
          <p>{data.personalInfo.location}</p>
        </div>
      </header>
      <div className="flex flex-1">
        <aside className="w-1/3 bg-slate-900 p-10 text-white">
          <section className="mb-12">
            <SectionHeader title="Expertise" accentColor="#fff" variant="sidebar" />
            <SkillSection skills={data.skills} accentColor={settings.accentColor} variant="sidebar" />
          </section>

          {/* Sidebar content ends here */}
        </aside>
        <main className="w-2/3 p-12 bg-white">
          {settings.sectionOrder
            .filter(id => !settings.hiddenSections.includes(id))
            .map(id => {
            if (id === 'summary') return (
              <section key="summary" className="mb-12">
                <SectionHeader title="The Story" accentColor={settings.accentColor} variant="sidebar" />
                <p className={cn("text-slate-600 leading-relaxed font-medium text-lg italic", fontSizeClass)}>{data.summary}</p>
              </section>
            );
            if (id === 'experience') return (
              <section key="experience" className="mb-12">
                <SectionHeader title="Journey" accentColor={settings.accentColor} variant="sidebar" />
                <div className="space-y-12">
                  {data.experience.map((exp, i) => (
                    <div key={i} className="group">
                      <div className="flex justify-between items-baseline mb-3">
                        <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors uppercase tracking-tight">{exp.position}</h3>
                        <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{exp.startDate} — {exp.endDate}</span>
                      </div>
                      <p className="text-xs font-black text-slate-400 mb-4 uppercase tracking-[0.2em]">{exp.company} / {exp.location}</p>
                      <ul className={cn("space-y-3", fontSizeClass)}>
                        {exp.highlights.map((h, j) => (
                          <li key={j} className="text-slate-600 flex gap-3 leading-relaxed">
                            <span style={{ color: settings.accentColor }} className="font-black text-lg leading-none">→</span>
                            {h}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </section>
            );
            if (id === 'projects' && data.projects && data.projects.length > 0) return (
              <section key="projects" className="mb-12">
                <SectionHeader title="Creations" accentColor={settings.accentColor} variant="sidebar" />
                <div className="grid grid-cols-1 gap-8">
                  {data.projects.map((proj, i) => (
                    <div key={i} className="group border-l-4 pl-6 py-2 hover:bg-slate-50 transition-all" style={{ borderColor: settings.accentColor }}>
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">{proj.name}</h3>
                        {proj.link && (
                          <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-black text-white px-2 py-1 rounded uppercase tracking-widest" style={{ backgroundColor: settings.accentColor }}>
                            Live ↗
                          </a>
                        )}
                      </div>
                      <p className={cn("text-slate-500 leading-relaxed mb-3", fontSizeClass)}>{proj.description}</p>
                      {proj.skills && (
                        <div className="flex flex-wrap gap-1.5">
                          {proj.skills.map((s, j) => <span key={j} className="text-[9px] font-black text-slate-300 uppercase tracking-tighter">#{s}</span>)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </section>
            );
            if (id === 'languages' && data.languages && data.languages.length > 0) return (
              <section key="languages" className="mb-12">
                <SectionHeader title="Languages" accentColor={settings.accentColor} variant="sidebar" />
                <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
              </section>
            );
            if (id === 'interests' && data.interests && data.interests.length > 0) return (
              <section key="interests" className="mb-12">
                <SectionHeader title="Interests" accentColor={settings.accentColor} variant="sidebar" />
                <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
              </section>
            );
            if (id === 'education' && data.education.length > 0) return (
              <section key="education" className="mb-12">
                <SectionHeader title="Education" accentColor={settings.accentColor} variant="sidebar" />
                <div className="space-y-8">
                  {data.education.map((edu, i) => (
                    <div key={i} className="group">
                      <div className="flex justify-between items-baseline mb-2">
                        <h3 className="text-base font-black text-slate-900 group-hover:text-indigo-600 transition-colors uppercase tracking-tight">{edu.degree}</h3>
                        <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{edu.graduationDate}</span>
                      </div>
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">{edu.school}</p>
                    </div>
                  ))}
                </div>
              </section>
            );
            return null;
          })}
        </main>
      </div>
    </div>
  );
};

export const ElegantTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-16 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl min-h-[1100px] border-x-[16px]", fontClass)} style={{ borderColor: settings.accentColor }}>
      <header className="text-center mb-16">
        <h1 className="text-5xl font-serif italic mb-6 tracking-tight">{data.personalInfo.fullName}</h1>
        <div className="flex justify-center gap-8 text-[10px] uppercase tracking-[0.3em] text-slate-400 font-bold">
          <span>{data.personalInfo.email}</span>
          <span>{data.personalInfo.phone}</span>
          <span>{data.personalInfo.location}</span>
        </div>
      </header>
      
      <div className="space-y-16">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary" className="text-center max-w-2xl mx-auto">
              <p className={cn("leading-relaxed text-slate-500 italic text-lg", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <SectionHeader title="Professional Journey" accentColor={settings.accentColor} variant="elegant" />
              <div className="space-y-12">
                {data.experience.map((exp, i) => (
                  <div key={i} className="text-center">
                    <div className="mb-6">
                      <h3 className="text-xl font-serif italic text-slate-900">{exp.position}</h3>
                      <p className="text-[10px] uppercase tracking-[0.2em] text-slate-400 mt-2 font-bold">{exp.company} — {exp.startDate} to {exp.endDate}</p>
                    </div>
                    <ul className={cn("max-w-xl mx-auto list-none text-slate-500 space-y-3 leading-relaxed", fontSizeClass)}>
                      {exp.highlights.map((h, j) => <li key={j}>{h}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'projects' && data.projects && data.projects.length > 0) return (
            <section key="projects">
              <SectionHeader title="Selected Works" accentColor={settings.accentColor} variant="elegant" />
              <div className="grid grid-cols-1 gap-12">
                {data.projects.map((proj, i) => (
                  <div key={i} className="text-center max-w-xl mx-auto">
                    <h3 className="text-lg font-serif italic mb-2">{proj.name}</h3>
                    <p className={cn("text-slate-500 mb-4 leading-relaxed", fontSizeClass)}>{proj.description}</p>
                    {proj.link && (
                      <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-colors border-b border-slate-200 pb-1">
                        Explore Project
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <SectionHeader title="Expertise" accentColor={settings.accentColor} variant="elegant" />
              <div className="max-w-xl mx-auto">
                <SkillSection skills={data.skills} accentColor={settings.accentColor} />
              </div>
            </section>
          );
          if (id === 'languages' && data.languages && data.languages.length > 0) return (
            <section key="languages">
              <SectionHeader title="Languages" accentColor={settings.accentColor} variant="elegant" />
              <div className="max-w-xl mx-auto text-center">
                <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
              </div>
            </section>
          );
          if (id === 'interests' && data.interests && data.interests.length > 0) return (
            <section key="interests">
              <SectionHeader title="Interests" accentColor={settings.accentColor} variant="elegant" />
              <div className="max-w-xl mx-auto text-center">
                <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
              </div>
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

export const CompactTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-8 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl min-h-[1100px]", fontClass)}>
      <div className="flex justify-between items-start border-b-2 pb-6 mb-8" style={{ borderColor: settings.accentColor }}>
        <div>
          <h1 className="text-3xl font-black tracking-tighter uppercase">{data.personalInfo.fullName}</h1>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">{data.experience[0]?.position}</p>
        </div>
        <div className="text-right text-[10px] font-bold text-slate-500 uppercase tracking-widest space-y-1">
          <p>{data.personalInfo.email}</p>
          <p>{data.personalInfo.phone}</p>
          <p>{data.personalInfo.location}</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-10">
        <div className="col-span-2 space-y-8">
          {settings.sectionOrder
            .filter(id => !settings.hiddenSections.includes(id))
            .map(id => {
            if (id === 'experience') return (
              <section key="experience">
                <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Experience</h2>
                <div className="space-y-6">
                  {data.experience.map((exp, i) => (
                    <div key={i} className="group">
                      <div className="flex justify-between font-black text-xs uppercase tracking-tight mb-1">
                        <span className="group-hover:text-indigo-600 transition-colors">{exp.position}</span>
                        <span className="text-slate-300">{exp.startDate} - {exp.endDate}</span>
                      </div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">{exp.company}</p>
                      <ul className={cn("list-disc ml-4 text-[10px] text-slate-600 space-y-1", fontSizeClass)}>
                        {exp.highlights.map((h, j) => <li key={j}>{h}</li>)}
                      </ul>
                    </div>
                  ))}
                </div>
              </section>
            );
            if (id === 'projects' && data.projects && data.projects.length > 0) return (
              <section key="projects">
                <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Projects</h2>
                <div className="space-y-4">
                  {data.projects.map((proj, i) => (
                    <div key={i} className="border-l-2 pl-4 py-1" style={{ borderColor: settings.accentColor }}>
                      <h3 className="text-[10px] font-black uppercase tracking-tight">{proj.name}</h3>
                      <p className={cn("text-[10px] text-slate-500 mt-1", fontSizeClass)}>{proj.description}</p>
                    </div>
                  ))}
                </div>
              </section>
            );
            return null;
          })}
        </div>
        <div className="space-y-8">
          <section>
            <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Expertise</h2>
            <SkillSection skills={data.skills} accentColor={settings.accentColor} />
          </section>
          {data.languages && data.languages.length > 0 && (
            <section>
              <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Languages</h2>
              <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
            </section>
          )}
          {data.interests && data.interests.length > 0 && (
            <section>
              <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Interests</h2>
              <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
            </section>
          )}
          <section>
            <h2 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Education</h2>
            <div className="space-y-4">
              {data.education.map((edu, i) => (
                <div key={i}>
                  <p className="text-[10px] font-black uppercase tracking-tight">{edu.degree}</p>
                  <p className="text-[9px] font-bold text-slate-400 mt-0.5">{edu.school}</p>
                  <p className="text-[8px] font-black text-slate-300 mt-1 uppercase">{edu.graduationDate}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export const ExecutiveTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-16 bg-white text-slate-900 max-w-[800px] mx-auto shadow-2xl min-h-[1100px] border-t-[24px] border-slate-900", fontClass)}>
      <header className="mb-16">
        <h1 className="text-5xl font-black tracking-tighter mb-4 uppercase">{data.personalInfo.fullName}</h1>
        <div className="flex gap-6 text-xs font-black uppercase tracking-[0.2em] text-slate-400">
          <span className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.email}</span>
          <span className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.phone}</span>
          <span className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: settings.accentColor }}></span>{data.personalInfo.location}</span>
        </div>
      </header>
      <div className="space-y-12">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-6 text-slate-400 border-b pb-2">Executive Summary</h2>
              <p className={cn("text-slate-700 leading-relaxed text-xl font-medium border-l-[6px] pl-8 py-2", fontSizeClass)} style={{ borderColor: settings.accentColor }}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-slate-400 border-b pb-2">Professional Experience</h2>
              <div className="space-y-12">
                {data.experience.map((exp, i) => (
                  <div key={i}>
                    <div className="flex justify-between items-baseline mb-2">
                      <h3 className="text-2xl font-black tracking-tight uppercase">{exp.company}</h3>
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{exp.startDate} — {exp.endDate}</span>
                    </div>
                    <p className="text-sm font-black text-slate-500 mb-6 uppercase tracking-[0.2em]" style={{ color: settings.accentColor }}>{exp.position}</p>
                    <ul className={cn("list-none text-slate-700 space-y-3", fontSizeClass)}>
                      {exp.highlights.map((h, j) => (
                        <li key={j} className="flex gap-4 leading-relaxed">
                          <span className="mt-2.5 w-1.5 h-1.5 flex-shrink-0 bg-slate-900"></span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'projects' && data.projects && data.projects.length > 0) return (
            <section key="projects">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-slate-400 border-b pb-2">Key Initiatives</h2>
              <div className="grid grid-cols-1 gap-8">
                {data.projects.map((proj, i) => (
                  <div key={i} className="bg-slate-50 p-8 rounded-3xl border border-slate-100 hover:bg-white hover:shadow-xl transition-all group">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-black uppercase tracking-tight">{proj.name}</h3>
                      {proj.link && (
                        <a href={proj.link} target="_blank" rel="noopener noreferrer" className="text-[10px] font-black text-white px-3 py-1.5 rounded-full uppercase tracking-widest transition-all group-hover:scale-105" style={{ backgroundColor: settings.accentColor }}>
                          Review ↗
                        </a>
                      )}
                    </div>
                    <p className={cn("text-slate-600 leading-relaxed", fontSizeClass)}>{proj.description}</p>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-slate-400 border-b pb-2">Strategic Skills</h2>
              <SkillSection skills={data.skills} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'languages' && data.languages && data.languages.length > 0) return (
            <section key="languages">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-slate-400 border-b pb-2">Languages</h2>
              <SimpleListSection items={data.languages} accentColor={settings.accentColor} />
            </section>
          );
          if (id === 'interests' && data.interests && data.interests.length > 0) return (
            <section key="interests">
              <h2 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-slate-400 border-b pb-2">Interests</h2>
              <SimpleListSection items={data.interests} accentColor={settings.accentColor} />
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

export const EditorialTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-16 bg-white text-slate-900 max-w-[800px] mx-auto min-h-[1100px]", fontClass)}>
      <header className="mb-16 border-b-4 border-slate-900 pb-8">
        <h1 className="text-7xl font-black uppercase leading-[0.8] tracking-tighter mb-6">{data.personalInfo.fullName}</h1>
        <div className="flex flex-wrap gap-x-8 gap-y-2 text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">
          <span>{data.personalInfo.email}</span>
          <span>{data.personalInfo.phone}</span>
          <span>{data.personalInfo.location}</span>
        </div>
      </header>

      <div className="grid grid-cols-[200px_1fr] gap-12">
        <aside className="space-y-12">
          <Section key="skills" id="skills" settings={settings}>
            <section>
              <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-6 text-slate-400">Expertise</h2>
              <div className="space-y-2">
                {(Array.isArray(data.skills) ? data.skills : []).map((skill, i) => (
                  <div key={i} className="text-xs font-bold border-b border-slate-100 pb-2">
                    {typeof skill === 'string' ? skill : skill.category}
                  </div>
                ))}
              </div>
            </section>
          </Section>

          <Section key="education" id="education" settings={settings}>
            <section>
              <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-6 text-slate-400">Education</h2>
              <div className="space-y-6">
                {data.education.map((edu, i) => (
                  <div key={i}>
                    <h3 className="text-xs font-black uppercase mb-1">{edu.degree}</h3>
                    <p className="text-[10px] font-bold text-slate-500">{edu.school}</p>
                  </div>
                ))}
              </div>
            </section>
          </Section>
        </aside>

        <main className="space-y-16">
          {settings.sectionOrder
            .filter(id => !['skills', 'education'].includes(id))
            .filter(id => !settings.hiddenSections.includes(id))
            .map(id => {
            if (id === 'summary') return (
              <section key="summary">
                <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-6 text-slate-400">Profile</h2>
                <p className={cn("text-xl font-medium leading-tight text-slate-800", fontSizeClass)}>{data.summary}</p>
              </section>
            );
            if (id === 'experience') return (
              <section key="experience">
                <h2 className="text-xs font-black uppercase tracking-[0.3em] mb-8 text-slate-400">Experience</h2>
                <div className="space-y-12">
                  {data.experience.map((exp, i) => (
                    <div key={i}>
                      <div className="flex justify-between items-baseline mb-4">
                        <h3 className="text-2xl font-black tracking-tight">{exp.position}</h3>
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{exp.startDate} — {exp.endDate}</span>
                      </div>
                      <p className="text-xs font-black uppercase tracking-widest text-indigo-600 mb-4">{exp.company}</p>
                      <ul className={cn("space-y-3 text-slate-600", fontSizeClass)}>
                        {exp.highlights.map((h, j) => (
                          <li key={j} className="relative pl-6 before:absolute before:left-0 before:top-2 before:w-2 before:h-[2px] before:bg-slate-200">
                            {h}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </section>
            );
            return null;
          })}
        </main>
      </div>
    </div>
  );
};

export const BrutalistTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-12 bg-white text-black max-w-[800px] mx-auto min-h-[1100px] border-[8px] border-black", fontClass)}>
      <header className="mb-12 border-b-[4px] border-black pb-8">
        <h1 className="text-6xl font-black uppercase leading-none tracking-tighter mb-4">{data.personalInfo.fullName}</h1>
        <div className="flex flex-wrap gap-4 text-xs font-bold uppercase tracking-widest">
          <span className="bg-black text-white px-2 py-1">{data.personalInfo.email}</span>
          <span className="bg-black text-white px-2 py-1">{data.personalInfo.phone}</span>
          <span className="bg-black text-white px-2 py-1">{data.personalInfo.location}</span>
        </div>
      </header>

      <div className="space-y-12">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary" className="border-l-[4px] border-black pl-6">
              <h2 className="text-xl font-black uppercase mb-4 italic">Profile</h2>
              <p className={cn("leading-tight font-bold", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <h2 className="text-xl font-black uppercase mb-6 bg-black text-white inline-block px-4 py-1">Experience</h2>
              <div className="space-y-8">
                {data.experience.map((exp, i) => (
                  <div key={i} className="border-b-[2px] border-black pb-6 last:border-0">
                    <div className="flex justify-between items-baseline mb-2">
                      <h3 className="text-lg font-black uppercase tracking-tight">{exp.position}</h3>
                      <span className="text-xs font-black border border-black px-2 py-0.5">{exp.startDate} - {exp.endDate}</span>
                    </div>
                    <p className="text-sm font-bold uppercase mb-4">{exp.company} // {exp.location}</p>
                    <ul className={cn("space-y-2", fontSizeClass)}>
                      {exp.highlights.map((h, j) => (
                        <li key={j} className="flex gap-2">
                          <span className="font-black">/</span>
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <h2 className="text-xl font-black uppercase mb-6 bg-black text-white inline-block px-4 py-1">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {(Array.isArray(data.skills) ? data.skills : []).map((skill, i) => (
                  <span key={i} className="border-[2px] border-black px-3 py-1 font-black uppercase text-xs hover:bg-black hover:text-white transition-colors">
                    {typeof skill === 'string' ? skill : skill.category}
                  </span>
                ))}
              </div>
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

export const LuxuryTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-20 bg-[#faf9f6] text-[#1a1a1a] max-w-[800px] mx-auto min-h-[1100px] border-[20px] border-white shadow-2xl", fontClass)}>
      <header className="text-center mb-20">
        <div className="inline-block border-y border-[#d4af37] py-6 px-12 mb-8">
          <h1 className="text-4xl font-serif tracking-[0.2em] uppercase mb-2">{data.personalInfo.fullName}</h1>
          <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-[#d4af37]">Curriculum Vitae</p>
        </div>
        <div className="flex justify-center gap-8 text-[9px] font-bold uppercase tracking-[0.2em] text-slate-400">
          <span>{data.personalInfo.email}</span>
          <span>•</span>
          <span>{data.personalInfo.phone}</span>
          <span>•</span>
          <span>{data.personalInfo.location}</span>
        </div>
      </header>

      <div className="max-w-2xl mx-auto space-y-16">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary" className="text-center italic">
              <p className={cn("text-lg leading-relaxed text-slate-700", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <div className="text-center mb-10">
                <h2 className="text-[10px] font-bold uppercase tracking-[0.5em] text-[#d4af37] mb-2">Experience</h2>
                <div className="w-8 h-[1px] bg-[#d4af37] mx-auto"></div>
              </div>
              <div className="space-y-12">
                {data.experience.map((exp, i) => (
                  <div key={i}>
                    <div className="text-center mb-4">
                      <h3 className="text-lg font-serif uppercase tracking-widest mb-1">{exp.position}</h3>
                      <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">{exp.company} // {exp.startDate} — {exp.endDate}</p>
                    </div>
                    <ul className={cn("space-y-3 text-slate-600 text-center max-w-xl mx-auto", fontSizeClass)}>
                      {exp.highlights.map((h, j) => <li key={j} className="leading-relaxed">{h}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            </section>
          );
          if (id === 'skills') return (
            <section key="skills">
              <div className="text-center mb-10">
                <h2 className="text-[10px] font-bold uppercase tracking-[0.5em] text-[#d4af37] mb-2">Expertise</h2>
                <div className="w-8 h-[1px] bg-[#d4af37] mx-auto"></div>
              </div>
              <div className="flex flex-wrap justify-center gap-x-8 gap-y-4">
                {(Array.isArray(data.skills) ? data.skills : []).map((skill, i) => (
                  <span key={i} className="text-[10px] font-bold uppercase tracking-widest border-b border-transparent hover:border-[#d4af37] transition-all cursor-default">
                    {typeof skill === 'string' ? skill : skill.category}
                  </span>
                ))}
              </div>
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};

export const GeometricTemplate: React.FC<TemplateProps> = ({ data, settings }) => {
  const fontClass = getFontClass(settings.fontFamily);
  const fontSizeClass = getFontSizeClass(settings.fontSize);

  return (
    <div className={cn("p-0 bg-white text-slate-900 max-w-[800px] mx-auto min-h-[1100px] overflow-hidden shadow-2xl", fontClass)}>
      <header className="relative bg-slate-900 text-white p-16 overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600 rotate-45 translate-x-32 -translate-y-32 opacity-20"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-400 -rotate-12 -translate-x-16 translate-y-16 opacity-10"></div>
        
        <div className="relative z-10">
          <h1 className="text-5xl font-black tracking-tighter mb-4">{data.personalInfo.fullName}</h1>
          <div className="flex flex-wrap gap-6 text-xs font-bold uppercase tracking-widest text-indigo-300">
            <span>{data.personalInfo.email}</span>
            <span>{data.personalInfo.phone}</span>
            <span>{data.personalInfo.location}</span>
          </div>
        </div>
      </header>

      <div className="p-16 space-y-16">
        {settings.sectionOrder
          .filter(id => !settings.hiddenSections.includes(id))
          .map(id => {
          if (id === 'summary') return (
            <section key="summary" className="relative">
              <div className="absolute -left-8 top-0 bottom-0 w-1 bg-indigo-600"></div>
              <h2 className="text-xs font-black uppercase tracking-[0.3em] text-indigo-600 mb-4">Profile</h2>
              <p className={cn("text-slate-600 leading-relaxed", fontSizeClass)}>{data.summary}</p>
            </section>
          );
          if (id === 'experience') return (
            <section key="experience">
              <h2 className="text-xs font-black uppercase tracking-[0.3em] text-indigo-600 mb-8">Experience</h2>
              <div className="space-y-12">
                {data.experience.map((exp, i) => (
                  <div key={i} className="grid grid-cols-[150px_1fr] gap-8">
                    <div className="text-xs font-black text-slate-400 uppercase tracking-widest pt-1">
                      {exp.startDate} — {exp.endDate}
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900 mb-1">{exp.position}</h3>
                      <p className="text-sm font-bold text-indigo-600 mb-4 uppercase tracking-widest">{exp.company}</p>
                      <ul className={cn("space-y-2 text-slate-600", fontSizeClass)}>
                        {exp.highlights.map((h, j) => <li key={j} className="relative pl-4 before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:bg-indigo-100 before:rounded-full">{h}</li>)}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          );
          return null;
        })}
      </div>
    </div>
  );
};
