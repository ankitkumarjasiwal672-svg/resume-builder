export interface SkillGroup {
  category: string;
  items: string[];
}

export interface ResumeData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedin?: string;
    website?: string;
  };
  summary: string;
  experience: Array<{
    company: string;
    position: string;
    location: string;
    startDate: string;
    endDate: string;
    highlights: string[];
  }>;
  education: Array<{
    school: string;
    degree: string;
    location: string;
    graduationDate: string;
  }>;
  skills: string[] | SkillGroup[];
  languages?: string[];
  interests?: string[];
  projects?: Array<{
    name: string;
    description: string;
    link?: string;
    skills?: string[];
  }>;
  certifications?: string[];
}

export type TemplateId = 'minimal' | 'modern' | 'technical' | 'professional' | 'creative' | 'elegant' | 'compact' | 'executive' | 'brutalist' | 'editorial' | 'luxury' | 'geometric';

export interface CustomizationSettings {
  fontFamily: 'sans' | 'serif' | 'mono' | 'display';
  fontSize: 'sm' | 'base' | 'lg';
  spacing: 'compact' | 'normal' | 'relaxed';
  accentColor: string;
  sectionOrder: string[];
  hiddenSections: string[];
}

export interface Template {
  id: TemplateId;
  name: string;
  description: string;
}
