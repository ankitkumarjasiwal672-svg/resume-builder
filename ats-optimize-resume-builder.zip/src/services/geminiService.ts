import { GoogleGenAI, Type } from "@google/genai";
import { ResumeData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const resumeSchema = {
  type: Type.OBJECT,
  properties: {
    personalInfo: {
      type: Type.OBJECT,
      properties: {
        fullName: { type: Type.STRING },
        email: { type: Type.STRING },
        phone: { type: Type.STRING },
        location: { type: Type.STRING },
        linkedin: { type: Type.STRING },
        website: { type: Type.STRING },
      },
      required: ["fullName", "email"],
    },
    summary: { type: Type.STRING },
    experience: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          company: { type: Type.STRING },
          position: { type: Type.STRING },
          location: { type: Type.STRING },
          startDate: { type: Type.STRING },
          endDate: { type: Type.STRING },
          highlights: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ["company", "position", "startDate", "endDate", "highlights"],
      },
    },
    education: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          school: { type: Type.STRING },
          degree: { type: Type.STRING },
          location: { type: Type.STRING },
          graduationDate: { type: Type.STRING },
        },
        required: ["school", "degree", "graduationDate"],
      },
    },
    skills: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "e.g., Languages, Frameworks, Tools, Soft Skills" },
          items: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ["category", "items"],
      },
    },
    projects: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          link: { type: Type.STRING },
          skills: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
      },
    },
    certifications: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    languages: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Languages spoken and proficiency levels."
    },
    interests: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Personal interests or hobbies."
    },
  },
  required: ["personalInfo", "summary", "experience", "education", "skills"],
};

export async function optimizeResume(rawText: string): Promise<ResumeData> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Extract and optimize the following resume content into a structured ATS-friendly format. 
    Focus on using strong action verbs, quantifiable achievements, and relevant keywords.
    
    CRITICAL: Categorize skills into logical groups (e.g., "Frontend", "Backend", "Tools", "Soft Skills") to make the resume more professional and scannable.
    
    Resume Content:
    ${rawText}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: resumeSchema,
    },
  });

  return JSON.parse(response.text || "{}") as ResumeData;
}

export async function updateResumeWithFeedback(
  currentData: ResumeData,
  feedback: string
): Promise<ResumeData> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Update the following resume data based on the user's request: "${feedback}".
    Maintain the ATS-friendly structure and optimize the content.
    
    Current Data:
    ${JSON.stringify(currentData)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: resumeSchema,
    },
  });

  return JSON.parse(response.text || "{}") as ResumeData;
}
